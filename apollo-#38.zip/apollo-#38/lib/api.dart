import 'dart:async';
import 'dart:math';
import 'dart:convert';
import 'package:awesome_poll_app/utils/commons.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:firebase_database/firebase_database.dart';
import 'package:injectable/injectable.dart';
import 'package:http/http.dart' as http;

import 'package:awesome_poll_app/services/auth/auth.service.dart';
import 'package:awesome_poll_app/services/location/location.service.dart';
/*
 * TODO use api as interface, allow easy emulator switch
 */

@firebase
@LazySingleton()
class API {
  static Logger logger = Logger.of('API');
  static const String pathUser = 'users';
  static const String pathOverview = 'poll-overview';
  static const String pathPollDetails = 'poll-details';
  static const String pathPolls = 'polls';
  static const String pathAnswers = 'poll-results';

  late DatabaseReference root;

  late DatabaseReference userPreferences;
  late DatabaseReference userPolls;
  late DatabaseReference pollDetails;
  late DatabaseReference pollLocations;
  late DatabaseReference pollResults;
  late String serverUrl;

  ValueNotifier<List<PollOverview>?> nearbyPolls = ValueNotifier(null);

  final List<Future> _initializers = [];

  API() {
    root = FirebaseDatabase(databaseURL: 'https://awesome-poll-app-default-rtdb.europe-west1.firebasedatabase.app/').reference();
    //root = FirebaseDatabase(databaseURL: 'http://127.0.0.1:9000/?ns=awesome-poll-app').reference();
    userPreferences = root.child('$pathUser/$_uid');
    userPolls = root.child('$pathOverview/$_uid');
    pollDetails = root.child(pathPollDetails);
    pollLocations = root.child(pathPolls);
    pollResults = root.child(pathAnswers);
    var assetsLoaded = loadAssets();
    _initializers.add(assetsLoaded);
  }

  loadAssets() async {
    serverUrl = await rootBundle.loadString('assets/serverurl.txt');
  }

  ///list of poll overviews of logged in user
  Stream<List<PollOverview>> listMyPollOverviewStream() async* {
    await initialized;
    yield* userPolls.onValue.map((e) => _toMap(e.snapshot.value)
        .entries
        .map((el) => PollOverview.fromDB(el.key, el.value))
        .toList());
  }

  ///updates all necessary entries within the database for an existing poll
  Future<void> updatePoll(Poll poll) async {
    await initialized;
    //TODO transactional/batch write
    var of = userPolls.child(poll.id).set(poll.toJsonPollOverview());
    var lf = pollLocations.child(poll.id).set(poll.toJsonPollOverviewLocation());
    var df = pollDetails.child(poll.id).set(poll.toJson());
    await Future.wait([of, lf, df]);
  }

  Future<void> updatePollOverview(PollOverview poll) async {
    await initialized;
    return await userPolls.child(poll.id).set(poll.toJsonPollOverview());
  }

  Future<Poll> loadPoll(String pollId) async {
    await initialized;
    var snapshot = await pollDetails.child(pollId).get();
    return Poll.fromDB(pollId, _toMap(snapshot.value));
  }

  Future<List<PollOverview>> listPollsNearby(double longitude, latitude) async {
    await initialized;
    var snapshot = await pollLocations.get();
    //TODO filter, do filtering as a function
    return Map.from(_toMap(snapshot.value))
        .entries
        .map((e) => PollOverviewLocation.fromDB(e.key, e.value))
        .toList();
  }

  Stream<List<PollOverview>> listPollsNearbyStream(double longitude, latitude) async* {
    await initialized;
    //TODO do the poll filtering server-side
    yield* pollLocations.onValue.map((e) => Map<String, dynamic>.from(_toMap(e.snapshot.value))
        .entries
        .map((el) => PollOverviewLocation.fromDB(el.key, el.value))
        .where((element) => _isInReach(element, longitude, latitude))
        .toList());
  }

  fetchListPollsNearby() async {
    await initialized;
    // Load location
    LocationData? locationData = await LocationService.getLocation();
    if (locationData == null || locationData.longitude == null ||
        locationData.latitude == null) {
      // set the value of nearbyPolls to null to indicate, that it could not be fetched
      nearbyPolls.value = null;
      return;
    }

    // Fetch poll list from backend
    var auth = getIt.get<AuthService>();
    Uri url = Uri.parse(serverUrl + '/api/listPollsNearby?longitude=' + locationData.longitude.toString() + '&latitude=' + locationData.latitude.toString());
    // final request = new http.Request("get", url);
    // final response = await request.send();
    final response = await http.get(url, headers: {"authorization": await auth.getUserTokenId()});

    if(response.statusCode==200) {
      // return await List<PollOverview>.filled(1, PollOverview("","",0,0,0));
      nearbyPolls.value = Map<String, dynamic>.from(json.decode(response.body))
          .entries
          .map((el) => PollOverview.fromDB(el.key, el.value)).toList();
    } else {
      nearbyPolls.value = null;
      throw Exception("Could not fetch polls from Backend");
    }
  }


  Future<void> vote({required String pollId, String? uid, required Map<String,dynamic> data}) async {
    await initialized;
    //TODO stricter typing
    await pollResults.child(pollId).child(uid ?? _uid).update(data);
  }

  ///returns raw db voting entries, grouped by hashed uid
  Future<Map<String, dynamic>> rawResults(String pollId) async {
    await initialized;
    return _toMap((await pollResults.child(pollId).get()).value);
  }

  bool _isInReach(PollOverviewLocation poll, double longitude, double latitude) {
    return pow((longitude - poll.longitude), 2) + pow((latitude - poll.latitude), 2) < poll.radius;
  }

  String generateKey({dynamic any}) => root.push().key!;

  String get _uid {
    var auth = getIt.get<AuthService>();
    logger.info('api bound to user: ${auth.uid}');
    return auth.uid;
  }

  Future<void> get initialized {
    var auth = getIt.get<AuthService>().initialized;
    return Future.wait([auth, ..._initializers]);
  }

  //TODO that's just stupid
  Map<String, dynamic> _toMap(dynamic any) => jsonDecode(jsonEncode(any));

}
