import 'dart:async';

import 'package:awesome_poll_app/utils/commons.dart';
import 'package:firebase_auth/firebase_auth.dart' as fb;
import 'package:injectable/injectable.dart';

Logger logger = Logger.of('AuthService');

//this only provides a uid within the tree
//forces an rebuild of the entire app when the auth state is changing
class AuthCubit extends Cubit<String?> {
  final AuthService auth;
  late final StreamSubscription _subscription;
  AuthCubit({required this.auth}) : super(null) {
    _subscription = auth.uidChanges.listen((e) => emit(e));
  }

  @override
  Future<void> close() async {
    await _subscription.cancel();
    return super.close();
  }
}

//forcing login screen to not show when logged in
class AuthObserver extends AutoRouterObserver {

  late final AppRouter rootRouter;

  AuthObserver({required this.rootRouter});

  @override
  void didPush(Route route, Route? previousRoute) async {
    var auth = getIt.get<AuthService>();
    await auth.initialized;
    if(auth.isLoggedIn() && route.settings.name == const LoginRoute().routeName) {
      rootRouter.navigate(const MainRoute());
    }
  }
}

//provides global authentication state, multiple login/logout/registration functionality
//TODO google auth and others, the auth calls seem quiet different for android/web
abstract class AuthService {
  bool isLoggedIn();
  Future<String> getUserTokenId();

  /// Registers a new user.
  /// Throws a [RegisterException] if registering did not succeed
  Future<void> registerWithEmailAndPassword(String email, String password, String passwordRepeat);

  /// Authenticates the user with the given data
  /// Throws a [LoginException] if the login did not succeed
  Future<void> loginWithEmailAndPassword(String email, String password);

  Future<void> logout();

  Stream<String?> get uidChanges;

  Future<void> get initialized;

  String get uid;

  @disposeMethod
  Future<void> dispose();
}

class RegisterException implements Exception {
  /// Can be one of the following:
  ///   - "passwords-differ" if the given password and the repeated password are different
  ///   - "weak-password" if the given password is too weak (the only rule seems to be at least 6 chars)
  ///   - "email-already-in-use" if the email address is already registered
  final String code;

  RegisterException(this.code); // constructor - initializes msg as given
}

class LoginException implements Exception {
  /// Can be one of the following:
  ///   - "user-not-found" if the email does not exist as user
  ///   - "wrong-password" if the password is wrong for the given email
  final String code;

  LoginException(this.code); // constructor - initializes msg as given
  // String errMsg() => code; //
}

//firebase implementation of AuthService
@firebase
@LazySingleton(as: AuthService) //lazy because they must be mutually exclusive
class FirebaseLogin implements AuthService {
  bool _loggedIn = false;

  late fb.FirebaseAuth _auth;

  StreamSubscription? _authChanges;

  final Completer <void> _initialized = Completer();

  FirebaseLogin() {
    _auth = fb.FirebaseAuth.instance;
    logger.info('initializing firebase login');
    _authChanges = _auth.authStateChanges().listen((fb.User? user) {
      if (user == null) {
        _loggedIn = false;
      } else {
        _loggedIn = true;
      }
      _initialized.complete();
    });
  }

  @override
  Stream<String?> get uidChanges => _auth.authStateChanges().map((e) => e?.uid);

  @override
  Future<void> get initialized => _initialized.future;

  @override
  bool isLoggedIn() {
    return _loggedIn;
  }

  @override
  Future<String> getUserTokenId() async {
    if(_auth.currentUser==null) {
      throw Exception("Not logged in");
    } 
    return _auth.currentUser!.getIdToken();
  }

  @override
  Future<void> registerWithEmailAndPassword(String email, String password, String passwordRepeat) async {
    if(password!=passwordRepeat) {
      throw RegisterException("passwords-differ");
    }
    try {
      fb.UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password
      );
    } on fb.FirebaseAuthException catch (e) {
      if (e.code == 'weak-password') {
        throw RegisterException("weak-password");
      } else if (e.code == 'email-already-in-use') {
        throw RegisterException("email-already-in-use");
      }
    } catch (e) {
      logger.error(e);
    }
  }


  @override
  Future<fb.UserCredential> loginWithEmailAndPassword(
      String email, String password) async {
    try {
      fb.UserCredential userCredential = await _auth.signInWithEmailAndPassword(
          email: email, password: password);
      return userCredential;
    } on fb.FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found') {
        throw LoginException('user-not-found');
      } else if (e.code == 'wrong-password') {
        throw LoginException('wrong-password');
      } else {
        rethrow;
      }
    } catch (e) {
      logger.error('an error occured');
      rethrow;
    }
  }

  @override
  Future<void> logout() async {
    await _auth.signOut();
  }

  @override
  String get uid {
    if (!_loggedIn) {
      Future.error('user is not logged in');
    }
    return _auth.currentUser!.uid;
  }

  @override
  Future<void> dispose() async {
    await _authChanges?.cancel();
  }
}

//in-memory implementation of AuthService
@local
@LazySingleton(as: AuthService)
class LocalLogin implements AuthService {
  bool _loggedIn = false;

  LocalLogin() {
    logger.info('initializing local login');
  }

  @override
  bool isLoggedIn() {
    return _loggedIn;
  }

  @override
  Future<String> getUserTokenId() {
    return Future.value("");
  }

  @override
  Future<void> registerWithEmailAndPassword(String email, String password, String passwordRepeat) async {
    logger.info("User wants to register with email " + email + " and password " + password + " and repeated password " + passwordRepeat + ".");
  }

  @override
  Future<void> loginWithEmailAndPassword(String email, String password) async {
    if (email == "test@test.test" && password == "test@test.test") {
      _loggedIn = true;
    } else {
      return Future.error('invalid credentials');
    }
  }

  @override
  Stream<String?> get uidChanges { //TODO
    throw UnimplementedError();
  }

  @override
  Future<void> get initialized async {

  }

  @override
  Future<void> logout() async {
    _loggedIn = false;
  }

  @override
  String get uid {
    if (!_loggedIn) {
      Future.error('user is not logged in');
    }
    return 'test_user';
  }

  @override
  Future<void> dispose() async {}
}
