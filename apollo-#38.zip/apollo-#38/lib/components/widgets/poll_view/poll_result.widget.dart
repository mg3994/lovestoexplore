import 'package:awesome_poll_app/utils/commons.dart';

class EmptyPollResult extends StatelessWidget {
  const EmptyPollResult({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) => Center(
    child: Text(context.lang('poll.view.results.empty'),
        style: Theme.of(context).textTheme.headline6,
    ),
  );
}