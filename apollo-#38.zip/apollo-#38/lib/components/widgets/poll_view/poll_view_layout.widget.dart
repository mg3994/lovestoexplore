import 'package:awesome_poll_app/components/widgets/location_picker.widget.dart';
import 'package:awesome_poll_app/utils/commons.dart';
import 'package:awesome_poll_app/services/poll_state/poll_view.dart';
import 'package:awesome_poll_app/utils/ordered_map.dart';

class PollViewLayoutWidget extends StatelessWidget {
  const PollViewLayoutWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      leading: IconButton(
        icon: const Icon(Icons.arrow_back),
        onPressed: () {
          //TODO do the context eval here
          BlocProvider.of<PollFormBloc>(context).add(PollFormEvent.cancelModify(context: context));
        },
      ),
      elevation: 3,
      title: BlocBuilder<ViewStateCubit, ViewState>(
          builder: (context, state) {
            return state.when(
              create: () => Text(context.lang('poll.view.title.create')),
              edit: (overview) => Text('${overview?.title} - ${context.lang('poll.view.title.active')}'),
              participate: (overview) => Text(context.lang('poll.view.title.participate')),
              result: (overview) => Text('${overview?.title} ${context.lang('poll.view.title.result')}'),
            );
          },
      ),
    ),
    body: Stack(
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: BlocProvider(
            create: (context) => context.read<PollFormBloc>().pollFormQuestionCubit,
            child: BlocBuilder<PollFormQuestionCubit, List<OrderedMapListEntry<PollQuestionTypeCubit>>>(
              builder: (context, state) {
                print('state $state');
                return Overlay(
                  key: UniqueKey(),
                  initialEntries: [
                    OverlayEntry(
                      builder: (context) => ReorderableListView(
                        header: _buildHeader(context),
                        //buildDefaultDragHandles: false,
                        onReorder: (int oldIndex, int newIndex) =>
                            context.read<PollFormBloc>().pollFormQuestionCubit.swap(oldIndex, newIndex),
                        children: [
                          //quickfix for missing ancestor provider
                          ...state.map((e) {
                            return _toPollWidget(context, e);
                          }).toList(),
                        ],
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ),
        //publish button
        Align(
          alignment: Alignment.bottomRight,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: BlocBuilder<ViewStateCubit, ViewState>(
              builder: (context, state) => state.maybeWhen(
                create: () => _buildActionButton(
                  context: context,
                  text: context.lang('poll.view.actions.publish'),
                  color: Theme.of(context).colorScheme.error,
                  action: const PollFormEvent.publishPoll(),
                ),
                edit: (poll) => const Placeholder(),
                participate: (poll) => _buildActionButton(
                  context: context,
                  text: context.lang('poll.view.actions.vote'),
                  color: Theme.of(context).colorScheme.error,
                  action: const PollFormEvent.pushResult(),
                ),
                orElse: () => Container(),
              ),
            ),
          ),
        ),
        Align(
          key: UniqueKey(),
          alignment: Alignment.center,
          child: BlocBuilder<ViewStateCubit, ViewState>(
            builder: (context, state) => state.maybeWhen(
                create: () => _buildQuestionAddButton(context),
                edit: (poll) => _buildQuestionAddButton(context),
                orElse: () => Container()),
          ),
        ),
      ],
    ),
  );

  Widget _buildActionButton({required BuildContext context, required PollFormEvent action, required String text, Color? color}) =>
      ElevatedButton(
        onPressed: () {
          context.read<PollFormBloc>().add(action);
        },
        style: ButtonStyle(
          shape: MaterialStateProperty.all<RoundedRectangleBorder>(RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18.0),
          )),
          backgroundColor: MaterialStateProperty.all<Color>(color ?? Theme.of(context).colorScheme.primary),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Text(text),
        ),
      );

  Widget _buildHeader(BuildContext context) => Column(
    key: UniqueKey(),
    children: [
      //title
      PollQuestionStyleWidget(
        leading: BlocBuilder<ViewStateCubit, ViewState>(
          builder: (context, state) => state.maybeWhen<Widget>(
            create: () => Text(
              context.lang('poll.view.fields.title'),
              style: Theme.of(context).textTheme.subtitle1,
            ),
            orElse: () => const Text(''),
          ),
        ),
        child: DefaultTextStyle(
          style: Theme.of(context).textTheme.headline5!,
          child: BlocBuilder<ViewStateCubit, ViewState>(
            builder: (context, state) => state.maybeWhen(
              participate: (poll) => Text('${poll?.title}'),
              result: (poll) => Text('${poll?.title}'),
              orElse: () => ReactiveTextField(
                formControl: BlocProvider.of<PollFormBloc>(context).title,
              ),
            ),
          ),
        ),
      ),
      //date
      BlocBuilder<ViewStateCubit, ViewState>(
        builder: (context, state) => state.maybeWhen(
          create: () => Column(
            children: [
              PollQuestionStyleWidget(
                leading: Text(context.lang('poll.view.fields.time.start')),
                child: PollViewDateWidget(
                  timestampControl: context.read<PollFormBloc>().startTimeControl,
                ),
              ),
              PollQuestionStyleWidget(
                leading: Text(context.lang('poll.view.fields.time.end')),
                child: PollViewDateWidget(
                  timestampControl: context.watch<PollFormBloc>().endTimeControl,
                  minStartTime: DateTime.now(),
                ),
              ),
            ],
          ),
          orElse: () => Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Flexible(
                child: Text(
                    DateTime.fromMillisecondsSinceEpoch(context.read<PollFormBloc>().startTime).format
                ),
              ),
              Flexible(
                child: Text(
                    DateTime.fromMillisecondsSinceEpoch(context.read<PollFormBloc>().endTime).format
                ),
              ),
            ],
          ),
        ),
      ),
      const SizedBox(height: 10),
      BlocBuilder<ViewStateCubit, ViewState>(
        builder: (context, state) => state.maybeWhen(
          create: () => PollQuestionStyleWidget(
              onTap: () async {
                var location = await Navigator
                    .push<CircleLocation?>(context, MaterialPageRoute(builder: (context) => const LocationPickerWidget()));
                print('actually: $location');
                if (location != null) {
                  var form = context.read<PollFormBloc>();
                  form.longitude.value = location.longitude;
                  form.latitude.value = location.latitude;
                  form.radius.value = location.radius;
                }
              },
              leading: const Icon(Icons.location_on),
              child: StreamBuilder( //TODO shouln't be here, not typesafe
                stream: context.read<PollFormBloc>().rootForm.valueChanges,
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    var data = snapshot.data as Map<String, dynamic>;
                    return Text('Long: ${data['longitude']} Lat: ${data['latitude']} Rad: ${data['radius']}');
                  }
                  return const Text('-');
                },
              )
          ),
          orElse: () => Container(),
        ),
      ),
    ],
  );

  Widget _buildQuestionAddButton(BuildContext context) => IconButton(
    icon: const Icon(Icons.add),
    onPressed: () => BlocProvider.of<PollFormBloc>(context).add(const PollFormEvent.addQuestion(type: PollQuestionType.single)),
  );

  //TODO doesn't seem to be working
  //quickfix for https://github.com/flutter/flutter/issues/88570, we just copy all necessary providers for each item...
  Widget _toPollWidget(BuildContext context, OrderedMapListEntry<PollQuestionTypeCubit> entry) => Container(
    key: ObjectKey(entry.key),
    child: Column(
      children: [
        BlocProvider<PollQuestionTypeCubit>(
          create: (context) => entry.value,
          child: PollQuestionControlWidget(
              id: entry.key,
          ),
        ),
        const SizedBox(height: 10),
        PollQuestionStyleWidget(
          child: Divider(
            color: Theme.of(context).colorScheme.primary,
          ),
        ),
      ],
    ),
  );
}

class PollQuestionControlWidget extends StatefulWidget {
  final String id;
  const PollQuestionControlWidget({Key? key, required this.id}) : super(key: key);
  @override
  State<StatefulWidget> createState() => _PollQuestionControlWidget();
}

class _PollQuestionControlWidget extends State<PollQuestionControlWidget> {
  bool _preview = false;
  @override
  Widget build(BuildContext context) {
    return BlocProvider<ViewStateCubit>(
      key: UniqueKey(),
      create: (_context) {
        if(_preview) {
          return ViewStateCubit(initial: const ViewState.participate());
        }
        //@dt this can become a problem, since we copy only the state, if changes to it occur, they wont propagate to the question
        return ViewStateCubit(initial: context.read<ViewStateCubit>().state);
      },
      child: PollQuestionStyleWidget(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              //question controls
              Row(
                children: [
                  Expanded(
                    child: BlocBuilder<ViewStateCubit, ViewState>(
                      builder: (context, state) => state.maybeWhen(
                          create: () => ReactiveTextField(
                            formControl: context.read<PollQuestionTypeCubit>().titleControl,
                          ),
                          orElse: () => Text(context.read<PollQuestionTypeCubit>().titleControl.value ?? '',
                            style: Theme.of(context).textTheme.headline5,
                          ),
                      ),
                    ),
                  ),
                  //preview
                  BlocBuilder<ViewStateCubit, ViewState>(
                    builder: (context, state) => state.maybeWhen(
                      create: () => _showPreview(),
                      orElse: () => Container(),
                    ),
                  ),
                  //type
                  BlocBuilder<ViewStateCubit, ViewState>(
                    builder: (context, state) => state.maybeWhen(
                      create: () => IconButton(
                        icon: BlocBuilder<PollQuestionTypeCubit, PollQuestionType>(
                          builder: (context, state) => state.when(
                              single: () => const Icon(Icons.radio_button_checked),
                              multiple: () => const Icon(Icons.check_box),
                              freeText: () => const Icon(Icons.notes)),
                        ),
                        onPressed: () async {
                          var type = await showDialog<PollQuestionType?>(
                            context: context,
                            builder: (context) => SimpleDialog(
                              title: Text(context.lang('poll.view.fields.question_type')),
                              children: [
                                SimpleDialogOption(
                                  child: Text(context.lang('poll.view.fields.question_type.single')),
                                  onPressed: () => Navigator.pop(context, PollQuestionType.single),
                                ),
                                SimpleDialogOption(
                                  child: Text(context.lang('poll.view.fields.question_type.multiple')),
                                  onPressed: () => Navigator.pop(context, PollQuestionType.multiple),
                                ),
                                /*
                              SimpleDialogOption(
                                child: Text(context.lang('poll.view.fields.question_type.free_text')),
                                onPressed: () => Navigator.pop(context, PollQuestionType.freeText),
                              ),
                              */
                              ],
                            ),
                          );
                          if(type != null) {
                            context.read<PollQuestionTypeCubit>().changeType(type);
                          }
                        },
                      ),
                      orElse: () => Container(),
                    ),
                  ),
                  if(_preview)
                    _showPreview(),
                  BlocBuilder<ViewStateCubit, ViewState>(
                    builder: (context, state) => state.maybeWhen(
                      create: () => PopupMenuButton(
                        icon: const Icon(Icons.more_vert),
                        itemBuilder: (context) => [
                          PopupMenuItem(
                            child: Text(context.lang('poll.view.actions.delete')),
                            onTap: () {
                              BlocProvider.of<PollFormBloc>(context).add(PollFormEvent.removeQuestion(id: widget.id));
                            },
                          ),
                        ],
                      ),
                      orElse: () => Container(),
                    ),
                  ),
                ],
              ),
              //actual question
              BlocBuilder<PollQuestionTypeCubit, PollQuestionType>(
                builder: (context, state) {
                  var question = BlocProvider.of<PollFormQuestionCubit>(context).forKey(widget.id);
                  return state.maybeWhen<Widget>(
                    //TODO other cases
                    single: () => SingleChoiceQuestionWidget(state: question as SingleChoiceQuestion),
                    multiple: () => MultipleChoiceQuestionWidget(state: question as MultipleChoiceQuestion),
                    freeText: () => throw UnimplementedError(),
                    orElse: () => const Placeholder(),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _showPreview() => IconButton(
    icon: _preview ? const Icon(Icons.visibility) : const Icon(Icons.visibility_off),
    onPressed: () {
      setState(() {
        _preview = !_preview;
      });
    },
  );
}

class PollQuestionStyleWidget extends StatelessWidget {
  final Widget? leading;
  final Widget child;
  final Color? color;
  final GestureTapCallback? onTap;
  const PollQuestionStyleWidget({
    Key? key,
    required this.child,
    this.leading,
    this.color,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) => ListTile(
    onTap: onTap,
    tileColor: color,
    leading: leading,
    title: Align(
      alignment: Alignment.centerLeft,
      child: child,
    ),
  );
}
