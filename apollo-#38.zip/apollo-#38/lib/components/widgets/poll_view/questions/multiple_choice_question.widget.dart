import 'package:awesome_poll_app/utils/commons.dart';
import 'package:awesome_poll_app/services/poll_state/poll_view.dart';
import 'package:fl_chart/fl_chart.dart';


class MultipleChoiceQuestionWidget extends StatefulWidget {
  final MultipleChoiceQuestion state;
  const MultipleChoiceQuestionWidget({Key? key, required this.state}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _MultipleChoiceQuestionWidget();

}

class _MultipleChoiceQuestionWidget extends State<MultipleChoiceQuestionWidget> {

  @override
  Widget build(BuildContext context) => BlocBuilder<ViewStateCubit, ViewState>(
    builder: (context, state) => state.maybeWhen(
      create: () => _buildEditableOptions(context),
      participate: (poll) => _buildParticipationOptions(context),
      result: (poll) => _buildResult(context),
      orElse: () => const Placeholder(),
    ),
  );

  Widget _buildResult(BuildContext context) {
    return LimitedBox(
      maxWidth: 200,
      maxHeight: 200,
      // TODO move this out, auto update,
      child: FutureBuilder(
          future: getIt.get<API>().rawResults(BlocProvider.of<PollFormBloc>(context).pollId!),
          builder: (context, snapshot) {
            if(snapshot.connectionState == ConnectionState.done) {
              if (snapshot.data == null) {
                return const EmptyPollResult();
              }
              //accumulate results
              int total = 0;
              Map<String, int> results = {};
              var data = snapshot.data as Map<String, dynamic>;
              widget.state.options.listEntries().forEach((element) {
                results.addAll({
                  element.key: 0,
                });
              });
              var els = data.values;
              for (Map<String, dynamic> el in els) {
                var option = el[widget.state.questionId];
                if (option != null && option is Map<String, dynamic>) {
                  //go through inner array
                  option.entries.forEach((element) {
                    if(element.value) {
                      var counted = results[element.key] ?? 0;
                      results[element.key] = counted + 1;
                      total++;
                    }
                  });
                }
              }
              context.debug('question: ${widget.state.questionId}, total votes: $total');
              List<PieChartSectionData> list = [
                ...results.entries.map((e) => PieChartSectionData(
                  value: e.value.toDouble(),
                  title: widget.state.options.find(e.key)!.value!,
                )).toList(),
              ];
              return PieChart(
                PieChartData(
                  sections: list,
                  centerSpaceRadius: double.infinity,
                ),
              );
            } else {
              return const CircularProgressIndicator();
            }
          }
      ),
    );
  }

  Widget _buildParticipationOptions(BuildContext context) => Column(
    children: widget.state.options
        .listEntries()
        .map<Widget>((e) => Column(
      children: [
        CheckboxListTile(
          title: Text(e.value.value ?? ''),
          value: widget.state.getVotedValue(e.key),
          onChanged: (value) {
            setState(() {
              if (value != null) widget.state.setVotedValue(e.key, value);
            });
          },
        ),
      ],
    )).toList(),
  );

  Widget _buildEditableOptions(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Column(
        children: widget.state.options.listEntries().map((e) => _buildOptionWidget(context, e.key, e.value)).toList(),
      ),
      IconButton(
          onPressed: () {
            setState(() {
              widget.state.addOption();
            });
          },
          icon: const Icon(Icons.add_circle_outline)),
    ],
  );

  Widget _buildOptionWidget(BuildContext context, String key, FormControl<dynamic> value) {
    return Row(
      key: ObjectKey(key),
      children: [
        Expanded(
          child: ReactiveTextField(
            formControl: value,
          ),
        ),
        ExcludeFocus(
          child: IconButton(
            onPressed: () {
              setState(() {
                widget.state.deleteOption(key);
              });
            },
            icon: Icon(
              Icons.remove_circle,
              color: Theme
                  .of(context)
                  .indicatorColor,
            ),
          ),
        )
      ],
    );
  }

}