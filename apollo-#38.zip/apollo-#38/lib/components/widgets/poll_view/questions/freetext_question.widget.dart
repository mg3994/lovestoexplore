import 'package:awesome_poll_app/utils/commons.dart';
import 'package:awesome_poll_app/services/poll_state/poll_view.dart';


class FreeTextQuestionWidget extends StatelessWidget {
  final FreeTextQuestion state;
  const FreeTextQuestionWidget({Key? key, required this.state}) : super(key: key);

  @override
  Widget build(BuildContext context) => BlocBuilder<ViewStateCubit, ViewState>(
    builder: (context, state) => state.maybeWhen(
      create: () => _buildEditable(context),
      edit: (poll) => _buildEditable(context),
      participate: (poll) => Text(this.state.freeTextFormField.value ?? ''),
      orElse: () => const Placeholder(),
    ),
  );

  Widget _buildEditable(BuildContext context) => ReactiveTextField(
    formControl: state.freeTextFormField,
  );

}