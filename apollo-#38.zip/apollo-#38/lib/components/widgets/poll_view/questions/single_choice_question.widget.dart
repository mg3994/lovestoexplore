import 'package:awesome_poll_app/utils/commons.dart';
import 'package:awesome_poll_app/services/poll_state/poll_view.dart';
import 'package:fl_chart/fl_chart.dart';


class SingleChoiceQuestionWidget extends StatefulWidget {
  final SingleChoiceQuestion state;
  const SingleChoiceQuestionWidget({Key? key, required this.state}) : super(key: key);
  @override
  State<StatefulWidget> createState() => _SingleChoiceQuestionWidget();
}

class _SingleChoiceQuestionWidget extends State<SingleChoiceQuestionWidget> {
  @override
  Widget build(BuildContext context) =>  BlocBuilder<ViewStateCubit, ViewState>(
    builder: (context, state) => state.maybeWhen(
    create: () => _buildEditableOptions(context),
    edit: (poll) => _buildEditableOptions(context),
    participate: (poll) => _buildParticipationOptions(context),
    result: (poll) => _buildResult(context),
    orElse: () => const Placeholder()),
  );

  Widget _buildResult(BuildContext context) {
    return LimitedBox(
      maxWidth: 200,
      maxHeight: 200,
      // TODO move this out, auto update,
      child: FutureBuilder(
        future: getIt.get<API>().rawResults(BlocProvider.of<PollFormBloc>(context).pollId!),
        builder: (context, snapshot) {
          if(snapshot.connectionState == ConnectionState.done) {
            if (snapshot.data == null) {
              return const EmptyPollResult();
            }
            //accumulate results
            int total = 0;
            Map<String, int> results = {};
            var data = snapshot.data as Map<String, dynamic>;
            widget.state.options.listEntries().forEach((element) {
              results.addAll({
                element.key: 0,
              });
            });
            var els = data.values;
            for (Map<String, dynamic> el in els) {
              context.debug('el: $el');
              var option = el[widget.state.questionId];
              if (option != null && results[option] != null) {
                results[option] = results[option]! + 1;
                total++;
              }
            }
            context.debug('question: ${widget.state.questionId}, total votes: $total');
            List<PieChartSectionData> list = [
              ...results.entries.map((e) => PieChartSectionData(
                value: e.value.toDouble(),
                title: widget.state.options.find(e.key)!.value!,
              )).toList(),
            ];
            return PieChart(
              PieChartData(
                sections: list,
                centerSpaceRadius: double.infinity,
              ),
            );
          } else {
            return const CircularProgressIndicator();
          }
        }
      ),
    );
  }

  Widget _buildParticipationOptions(BuildContext context) => Column(
        children: widget.state.options
            .listEntries()
            .map<Widget>((e) => Column(
                  children: [
                    RadioListTile<String>(
                      title: Text(e.value.value ?? ''),
                      value: e.key,
                      groupValue: widget.state.votedValue,
                      onChanged: (value) {
                        setState(() {
                          if (value != null) widget.state.votedValue = value;
                        });
                      },
                    )
                  ],
                ))
            .toList(),
      );

  Widget _buildEditableOptions(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            children: widget.state.options.listEntries().map((e) => _buildOptionWidget(context, e.key, e.value)).toList(),
          ),
          IconButton(
              onPressed: () {
                setState(() {
                  widget.state.addOption();
                });
              },
              icon: const Icon(Icons.add_circle_outline)),
        ],
      );

  Widget _buildOptionWidget(BuildContext context, String key, FormControl<dynamic> value) {
    return Row(
      key: ObjectKey(key),
      children: [
        Expanded(
          child: ReactiveTextField(
            formControl: value,
          ),
        ),
        ExcludeFocus(
          child: IconButton(
            onPressed: () {
              setState(() {
                widget.state.deleteOption(key);
              });
            },
            icon: Icon(
              Icons.remove_circle,
              color: Theme.of(context).indicatorColor,
            ),
          ),
        )
      ],
    );
  }
}
