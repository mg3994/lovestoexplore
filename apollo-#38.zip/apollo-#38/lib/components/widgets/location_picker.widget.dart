import 'dart:async';

import 'package:awesome_poll_app/components/widgets/animations/dashed_circle.widget.dart';
import 'package:awesome_poll_app/utils/commons.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:maps_toolkit/maps_toolkit.dart' as map_utils;
import 'package:google_maps_flutter/google_maps_flutter.dart';

class LocationPickerWidget extends StatefulWidget {
  const LocationPickerWidget({
    Key? key,
  }) : super(key: key);

  @override
  State<StatefulWidget> createState() => _LocationPickerWidget();

}

class _LocationPickerWidget extends State<LocationPickerWidget> {
  CircleLocation _circleLocation = CircleLocation(
    radius: 100,
    latitude: 12,
    longitude: 49.877971
  );
  final Completer<GoogleMapController> _mapsController = Completer();

  @override
  Widget build(BuildContext context) => Scaffold(
    body: Stack(
      children: [
        Builder(
          builder: (context) => GoogleMap(
            tiltGesturesEnabled: false,
            zoomControlsEnabled: false,
            onMapCreated: (e) => _mapsController.complete(e),
            onCameraMove: (_) => _whenMapsReady((c) => _updateInternalCircleLocation(c)),
            onCameraIdle: () => _whenMapsReady((c) => _updateInternalCircleLocation(c)),
            gestureRecognizers: {
              Factory(() => PanGestureRecognizer()),
            },
            initialCameraPosition: const CameraPosition(
              zoom: 14,
              target: LatLng(49.877971, 12),
            ),
          ),
        ),
        Builder(
          builder: (context) => Center(
            child: GestureDetector(
              behavior: HitTestBehavior.translucent,
              child: IgnorePointer(
                child: CustomPaint(
                  size: Size.square(_calculateCircleSize()),
                  painter: DashedCirclePainter(),
                ),
              ),
            ),
          ),
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: IconButton(
            iconSize: 44,
            icon: const Icon(Icons.location_on),
            onPressed: () => Navigator.pop(context, _circleLocation),
          ),
        )
      ],
    ),
  );

  void _whenMapsReady(Function(GoogleMapController controller) whenReady) async {
    if(_mapsController.isCompleted) {
      whenReady(await _mapsController.future);
    }
  }

  double _calculateCircleSize() {
    const ratio = 0.75;
    var length = MediaQuery.of(context).size.shortestSide;
    return length * ratio;
  }

  void _updateInternalCircleLocation(GoogleMapController controller) async {
    var size = MediaQuery.of(context).size;
    var center = ScreenCoordinate(x: size.width~/2 , y: size.height~/2);
    var coords = controller.getLatLng(center);
    //radius
    var rpx = _calculateCircleSize()~/2;
    var deg0 = ScreenCoordinate(x: center.x + rpx, y: center.y);
    var r = controller.getLatLng(deg0);
    var res = await Future.wait([coords, r]);
    _circleLocation = CircleLocation(
      longitude: res[0].longitude,
      latitude: res[0].latitude,
      radius: map_utils.SphericalUtil
          .computeDistanceBetween(
          map_utils.LatLng(res[0].latitude, res[0].longitude),
          map_utils.LatLng(res[1].latitude, res[1].longitude)) as double,
    );
    context.debug(_circleLocation);
  }

}