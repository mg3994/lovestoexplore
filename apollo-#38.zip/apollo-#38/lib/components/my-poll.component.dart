import 'package:awesome_poll_app/utils/commons.dart';
import 'package:grouped_list/grouped_list.dart';

class MyPollComponent extends StatefulWidget {
  const MyPollComponent({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return _MyPollComponent();
  }
}

class _MyPollComponent extends State<MyPollComponent> {
  final ScrollController _scrollController = ScrollController();
  String status =
      ''; // status for whether poll is "active", "expired", or "upcoming"

  Color _statusColor(int startTime, int endTime) {
    if (endTime.compareTo(DateTime.now().millisecondsSinceEpoch) == -1) {
      return const Color(0xffFFA69E);
    } else if (endTime.compareTo(DateTime.now().millisecondsSinceEpoch) == 1 &&
        startTime.compareTo(DateTime.now().millisecondsSinceEpoch) == -1) {
      return const Color(0xff2A9D8F);
    } else if (startTime.compareTo(DateTime.now().millisecondsSinceEpoch) ==
        1) {
      return const Color(0xff979797);
    } else {
      return const Color(0xffffffff);
    }
  }

  Color _statusColorByString(String status) {
    if (status == 'expired') {
      return const Color(0xffFFA69E);
    } else if (status == 'active') {
      return const Color(0xff2A9D8F);
    } else if (status == 'upcoming') {
      return const Color(0xff979797);
    } else {
      return const Color(0xff000000);
    }
  }

  String _status(int startTime, int endTime) {
    if (endTime.compareTo(DateTime.now().millisecondsSinceEpoch) == -1) {
      status = 'expired';
      return status;
    } else if (endTime.compareTo(DateTime.now().millisecondsSinceEpoch) == 1 &&
        startTime.compareTo(DateTime.now().millisecondsSinceEpoch) == -1) {
      status = 'active';
      return status;
    } else if (startTime.compareTo(DateTime.now().millisecondsSinceEpoch) ==
        1) {
      status = 'upcoming';
      return status;
    } else {
      return status;
    }
  }

  String _subtitle(PollOverview item) {
    Duration active = DateTime.fromMillisecondsSinceEpoch(item.endTime)
        .difference(DateTime.now());
    Duration expired = DateTime.now()
        .difference(DateTime.fromMillisecondsSinceEpoch(item.endTime));
    Duration upcoming = DateTime.fromMillisecondsSinceEpoch(item.startTime)
        .difference(DateTime.now());

    if (_status(item.startTime, item.endTime) == 'active') {
      if (active.inDays > 1) {
        return 'ends in ${active.inDays} days \npeople voted: ${item.participants}';
      } else if (active.inDays == 1) {
        return 'ends in ${active.inDays} day \npeople voted: ${item.participants}';
      } else if (active.inHours > 0) {
        return 'ends in ${active.inHours} hours \npeople voted: ${item.participants}';
      } else if (active.inHours == 1) {
        return 'ends in ${active.inHours} hour \npeople voted: ${item.participants}';
      } else if (active.inMinutes > 1) {
        return 'ends in ${active.inMinutes} minutes \npeople voted: ${item.participants}';
      } else if (active.inMinutes == 1) {
        return 'ends in ${active.inMinutes} minute \npeople voted: ${item.participants}';
      } else if (active.inSeconds > 1) {
        return 'ends in ${active.inSeconds} seconds \npeople voted: ${item.participants}';
      } else if (active.inSeconds == 1) {
        return 'ends in ${active.inSeconds} second \npeople voted: ${item.participants}';
      }
    } else if (_status(item.startTime, item.endTime) == 'expired') {
      if (expired.inDays > 1) {
        return 'ended ${expired.inDays} days ago \npeople voted: ${item.participants}';
      } else if (expired.inDays == 1) {
        return 'ended ${expired.inDays} day ago \npeople voted: ${item.participants}';
      } else if (expired.inHours > 1) {
        return 'ended ${expired.inHours} hours ago \npeople voted: ${item.participants}';
      } else if (expired.inHours == 1) {
        return 'ended ${expired.inHours} hour ago \npeople voted: ${item.participants}';
      } else if (expired.inMinutes > 1) {
        return 'ended ${expired.inMinutes} minutes ago \npeople voted: ${item.participants}';
      } else if (expired.inMinutes == 1) {
        return 'ended ${expired.inMinutes} minute ago \npeople voted: ${item.participants}';
      } else if (expired.inSeconds > 1) {
        return 'ended ${expired.inSeconds} seconds ago \npeople voted: ${item.participants}';
      } else if (expired.inSeconds == 1) {
        return 'ended ${expired.inSeconds} second ago \npeople voted: ${item.participants}';
      }
    } else if (_status(item.startTime, item.endTime) == 'upcoming') {
      if (upcoming.inDays > 1) {
        return 'starts in ${upcoming.inDays} days';
      } else if (upcoming.inDays == 1) {
        return 'starts in ${upcoming.inDays} day';
      } else if (upcoming.inHours > 1) {
        return 'starts in ${upcoming.inHours} hours';
      } else if (upcoming.inHours == 1) {
        return 'starts in ${upcoming.inHours} hour';
      } else if (upcoming.inMinutes > 1) {
        return 'starts in ${upcoming.inMinutes} minutes';
      } else if (upcoming.inMinutes == 1) {
        return 'starts in ${upcoming.inMinutes} minute';
      } else if (upcoming.inSeconds > 1) {
        return 'starts in ${upcoming.inSeconds} seconds';
      } else if (upcoming.inSeconds == 1) {
        return 'starts in ${upcoming.inSeconds} second';
      }
    }
    return '';
  }

  Widget edit(PollOverview item) {
    TextButton button = TextButton(
      onPressed: () {},
      child: const Icon(Icons.edit, color: Colors.black),
    );
    SizedBox box = const SizedBox();
    if (_status(item.startTime, item.endTime) == 'expired') {
      return box;
    }
    return button;
  }

  Color _tileColor() {
    bool _darkModeEnabled = false;

    if (Theme.of(context).brightness == Brightness.dark) {
      Color background = Theme.of(context).colorScheme.background;
      double p = 0.1;

      return Color.fromARGB(
          background.alpha,
          background.red + ((255 - background.red) * p).round(),
          background.green + ((255 - background.green) * p).round(),
          background.blue + ((255 - background.blue) * p).round());
    } else {
      Color background = Theme.of(context).colorScheme.background;
      double p = 0.9;

      return Color.fromARGB(background.alpha, (background.red * p).round(),
          (background.green * p).round(), (background.blue * p).round());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          StreamBuilder(
            stream: getIt.get<API>().listMyPollOverviewStream(),
            builder: (streamContext, snapshot) {
              final items = <PollOverview>[];

              if (snapshot.hasData) {
                //add data from db
                var polls = snapshot.data as List<PollOverview>;
                context.debug('$polls');
                items.addAll(polls);
              } else {
                return Center(
                  child: Text(
                    'You don\'t have any polls yet!',
                    style: Theme.of(context).textTheme.headline5,
                  ),
                );
              }

              return GroupedListView<PollOverview, String>(
                  elements: items,
                  scrollDirection: Axis.vertical,
                  controller: _scrollController,
                  itemComparator: (item1, item2) {
                    if (_status(item1.startTime, item1.endTime) == 'upcoming') {
                      return item1.startTime.compareTo(item2.startTime);
                    } else {
                      return item2.endTime.compareTo(item1.endTime);
                    }
                  },
                  groupBy: (item) => _status(item.startTime, item.endTime),
                  groupSeparatorBuilder: (value) => Container(
                        child: SizedBox(
                          height: 30,
                          child: DecoratedBox(
                            decoration: BoxDecoration(
                              color: _statusColorByString(value),
                            ),
                          ),
                        ),
                      ),
                  physics: const AlwaysScrollableScrollPhysics(),
                  indexedItemBuilder: (_context, item, index) {
                    return InkWell(
                      onTap: () => {
                        context.debug('tapped index $index , poll id: ${items[index].id}'),
                        context.router
                            .push(PollResultRoute(pollId: items[index].id, overview: items[index])),
                      },
                      splashColor: Theme.of(context).colorScheme.secondary,
                      highlightColor: Theme.of(context).colorScheme.primary,
                      child: ListBody(children: [
                        Column(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              ListTile(
                                contentPadding: const EdgeInsets.only(left: 20),
                                leading: SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: DecoratedBox(
                                    decoration: BoxDecoration(
                                      color: _statusColor(
                                          item.startTime, item.endTime),
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                ), //const Icon(Icons.radar_rounded),
                                title: Text(item.title),
                                subtitle: Text(_subtitle(item)),
                                trailing: edit(item),
                                tileColor:
                                    Theme.of(context).colorScheme.background,
                              ),
                            ])
                      ]),
                    );
                  });
            },
          ),
          Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                padding: const EdgeInsets.all(20),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    shape: CircleBorder(),
                    padding: EdgeInsets.all(20),
                    // primary: Colors.blue,
                    // onPrimary: Colors.blueAccent,
                  ),
                  child: Icon(Icons.add),
                  onPressed: () {
                    context.debug('pressed poll add button');
                    context.router.navigate(const PollCreateRoute());
                  },
                ),
              ))
        ],
      ),
    );
  }
}
