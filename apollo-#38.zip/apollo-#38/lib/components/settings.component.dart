import 'dart:io';
import 'package:awesome_poll_app/utils/commons.dart';
import 'package:awesome_poll_app/services/auth/auth.service.dart';
import 'package:awesome_poll_app/services/lang/language.service.dart';

class SettingsComponent extends StatefulWidget {
  const SettingsComponent({Key? key}) : super(key: key);

  @override
  State<SettingsComponent> createState() => _SettingsComponentState();
}

class _SettingsComponentState extends State<SettingsComponent> {

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(context.lang('app.nav.settings'),
        style: Theme.of(context).textTheme.headline5,
      ),
      actions: [
        PopupMenuButton(
          icon: const Icon(Icons.expand_more),
          itemBuilder: (context) => [
            PopupMenuItem(
              child: Row(
                children: [
                  const Icon(Icons.logout),
                  Text(context.lang('settings.menu.logout')),
                ],
              ),
            ),
          ],
        ),
      ],
    ),
    body: SingleChildScrollView(
      child: Column(
        children: [
          ListTile(
            leading: const Icon(Icons.panorama),
            title: Text(context.lang('settings.menu.appearance')),
            trailing: BlocBuilder<AppThemeCubit, CustomTheme>(
              builder: (context, state) => Text(context.lang('theme.${state.name}')),
            ),
            onTap: () async {
              var theme = await showDialog<CustomTheme?>(
                context: context,
                builder: (context) => SimpleDialog(
                  title: Text(context.lang('settings.menu.appearance')),
                  children: [
                    /* //TODO system settings?
                    SimpleDialogOption(
                      child: Text(context.lang('theme.system')),
                      onPressed: () => Navigator.pop(context, e),
                    ),
                     */
                    ...Themes.listThemes().map((e) => SimpleDialogOption(
                      child: Text(context.lang('theme.${e.name}')),
                      onPressed: () => Navigator.pop(context, e),
                    )).toList(),
                  ],
                ),
              );
              if (theme != null) {
                context.read<AppThemeCubit>().theme = theme;
              }
            },
          ),
          ListTile(
            leading: const Icon(Icons.language),
            title: Text(context.lang('settings.menu.notification')),
          ),
          ListTile(
            leading: const Icon(Icons.lock),
            title: Text(context.lang('settings.menu.privacy')),
          ),
          ListTile(
            leading: const Icon(Icons.language),
            title: Text(context.lang('settings.menu.language')),
            trailing: Text(context.stringifyLocale(context.watch<LocalizationCubit>().state)),
            onTap: () async {
              var lang = await showDialog<Locale?>(
                context: context,
                builder: (context) => SimpleDialog(
                  title: Text(context.lang('settings.menu.language')),
                  children: [
                    //TODO system
                    if(_supportsSystemLocale(context) != null)
                      SimpleDialogOption(
                        child: Text(context.lang('language.system')),
                        onPressed: () => Navigator.pop(context, _supportsSystemLocale(context)),
                      ),
                    ...context.read<LocalizationCubit>().listLocales().map((e) => SimpleDialogOption(
                      child: Text(context.stringifyLocale(e)),
                      onPressed: () => Navigator.pop(context, e),
                    )).toList()
                  ],
                ),
              );
              if (lang != null) {
                context.read<LocalizationCubit>().changeLocale(lang);
              }
            },
          ),
          const Divider(),
          //Help
          ListTile(
            leading: const Icon(Icons.contact_support),
            title: Text(context.lang('settings.menu.about')),
            onTap: () => showAboutDialog(
              context: context,
              applicationName: 'Apollo',
              applicationIcon: const FlutterLogo(),
              applicationVersion: '0.0.0',
            ),
          ),
          ListTile(
            leading: const Icon(Icons.verified_user),
            title: Text(context.lang('settings.menu.policy')),
          ),
          ListTile(
            leading: const Icon(Icons.logout),
            title: Text(context.lang('settings.menu.logout')),
            onTap: () {
              getIt.get<AuthService>().logout();
            },
          ),
        ],
      ),
    ),
  );

  /// looks platform language and returns locale if supported
  Locale?  _supportsSystemLocale(BuildContext context) {
    try {
      var localLocale = Locale(Platform.localeName);
      var target = BlocProvider.of<LocalizationCubit>(context).listLocales()
          .firstWhere((element) => element.toLanguageTag() == localLocale.toLanguageTag());
      return target;
    } catch (e) {
      //debugPrint('$e');
    }
    return null;
  }

}