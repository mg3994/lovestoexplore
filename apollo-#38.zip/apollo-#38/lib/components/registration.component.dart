import 'package:awesome_poll_app/utils/commons.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:awesome_poll_app/services/auth/auth.service.dart';

class RegistrationComponent extends StatefulWidget {
  const RegistrationComponent({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _RegistrationComponent();
}

class _RegistrationComponent extends State<RegistrationComponent> {
  String? someErrorMessage;
  bool _obscureText = true;

  @override
  Widget build(BuildContext context) {
    FormGroup registerForm() => FormGroup({
          'email': FormControl<String>(
            value: '',
            validators: [Validators.required, Validators.email],
          ),
          'password': FormControl<String>(
            value: '',
            validators: [Validators.required],
          ),
          'passwordRepeat': FormControl<String>(
            value: '',
            validators: [Validators.required],
          )
        }, validators: [
          Validators.mustMatch('password', 'passwordRepeat'),
        ]);

    return Scaffold(
        backgroundColor: const Color(0xff1D3557),
        body: Padding(
            padding: const EdgeInsets.all(30),
            child: Center(
                child: SingleChildScrollView(
                    child: ConstrainedBox(
                        constraints: const BoxConstraints(
                          maxWidth: 360,
                        ),
                        child: Container(
                            padding: const EdgeInsets.all(30),
                            child: Column(
                              children: [
                                Text("Polling App",
                                    style: GoogleFonts.ribeyeMarrow(
                                        textStyle: const TextStyle(
                                      color: Color(0xffFCBF49),
                                      fontSize: 42,
                                    ))),
                                const SizedBox(
                                  height: 100,
                                ),
                                ReactiveFormBuilder(
                                  form: registerForm,
                                  builder: (formContext, form, child) {
                                    return Column(
                                      children: <Widget>[
                                        Row(
                                          children: const [
                                            Text('Email',
                                                style: TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 15)),
                                            SizedBox(
                                              height: 15,
                                            )
                                          ],
                                        ),
                                        ReactiveTextField(
                                          validationMessages: (control) => {
                                            'required': 'Field cannot be empty',
                                            'email':
                                                'Please enter an valid email',
                                          },
                                          decoration: const InputDecoration(
                                              errorStyle: TextStyle(
                                                color: Colors.red,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 14,
                                              ),
                                              filled: true,
                                              fillColor: Colors.white,
                                              border: OutlineInputBorder(),
                                              hintText:
                                                  'Enter your email address',
                                              hintStyle: TextStyle(
                                                  color: Colors.black)),
                                          formControlName: 'email',
                                        ),
                                        const SizedBox(
                                          height: 15,
                                        ),
                                        Row(
                                          children: const [
                                            Text('Password',
                                                style: TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 15)),
                                            SizedBox(
                                              height: 15,
                                            )
                                          ],
                                        ),
                                        ReactiveTextField(
                                          validationMessages: (control) => {
                                            'required': 'Field cannot be empty',
                                            'email':
                                                'Please enter an valid email',
                                          },
                                          decoration: InputDecoration(
                                            errorStyle: const TextStyle(
                                              color: Colors.red,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 14,
                                            ),
                                            filled: true,
                                            fillColor: Colors.white,
                                            border: const OutlineInputBorder(),
                                            hintText: 'Enter your password',
                                            hintStyle: const TextStyle(
                                                color: Colors.black),
                                            suffixIcon: IconButton(
                                                icon: Icon(
                                                  // Based on passwordVisible state choose the icon
                                                  _obscureText
                                                      ? Icons.visibility_off
                                                      : Icons.visibility,
                                                  color:
                                                      const Color(0xff111111),
                                                ),
                                                onPressed: () {
                                                  setState(() {
                                                    _obscureText =
                                                        !_obscureText;
                                                  });
                                                }),
                                          ),
                                          formControlName: 'password',
                                          obscureText: _obscureText,
                                        ),
                                        const SizedBox(
                                          height: 15,
                                        ),
                                        Row(
                                          children: const [
                                            Text('Password Confirmation',
                                                style: TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 15)),
                                            SizedBox(
                                              height: 15,
                                            )
                                          ],
                                        ),
                                        ReactiveTextField(
                                          validationMessages: (control) => {
                                            'required': 'Field cannot be empty',
                                            'mustMatch':
                                                'Passwords don\'t match',
                                          },
                                          decoration: const InputDecoration(
                                            errorStyle: TextStyle(
                                              color: Colors.red,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 14,
                                            ),
                                            filled: true,
                                            fillColor: Colors.white,
                                            border: OutlineInputBorder(),
                                            hintText:
                                                'Enter your password again',
                                            hintStyle:
                                                TextStyle(color: Colors.black),
                                          ),
                                          formControlName: 'passwordRepeat',
                                          obscureText: _obscureText,
                                        ),
                                        const SizedBox(
                                          height: 100,
                                        ),
                                        MaterialButton(
                                            color: const Color(0xff2A9D8F),
                                            minWidth: 360,
                                            height: 50,
                                            onPressed: () async {
                                              if (!form.hasErrors) {
                                                var auth =
                                                    getIt.get<AuthService>();
                                                try {
                                                  //TODO: we might want to show a loading animation while auth request is being processed, 'FutureBuilder' seems promising
                                                  await auth
                                                      .registerWithEmailAndPassword(
                                                          form
                                                              .control('email')
                                                              .value,
                                                          form
                                                              .control(
                                                                  'password')
                                                              .value,
                                                          form
                                                              .control(
                                                                  'passwordRepeat')
                                                              .value);
                                                  var canPop = await context
                                                      .router
                                                      .pop();
                                                  if (!canPop) {
                                                    context.router
                                                        .replaceNamed('/');
                                                  }
                                                } on RegisterException catch (e) {
                                                  if (e.code ==
                                                      'passwords-differ') {
                                                    setState(() {
                                                      someErrorMessage =
                                                          'The passwords you typed are not equal.';
                                                    });
                                                  } else if (e.code ==
                                                      'weak-password') {
                                                    // TODO: Implement a validator that enforces at least six chars (this is forced by Firebase)
                                                    setState(() {
                                                      someErrorMessage =
                                                          'The password is to weak.';
                                                    });
                                                  } else if (e.code ==
                                                      'email-already-in-use') {
                                                    setState(() {
                                                      someErrorMessage =
                                                          'An account with that email address already exists.';
                                                    });
                                                  }
                                                } catch (e) {
                                                  context.error('Login failed $e');
                                                }
                                              } else {
                                                setState(() {
                                                  someErrorMessage =
                                                      'form validation failed, skipping login attempt';
                                                });
                                              }
                                            },
                                            child: const Text("Create Account",
                                                style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 16,
                                                ))),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Text('Already have an account?',
                                                style: TextStyle(
                                                  color: Colors.white
                                                      .withOpacity(0.5),
                                                )),
                                            TextButton(
                                              child: const Text('Sign in',
                                                  style: TextStyle(
                                                      color:
                                                          Color(0xffFCBF49))),
                                              onPressed: () {
                                                context.router.popUntilRoot();
                                                context.router
                                                    .replaceNamed('/');
                                              },
                                            )
                                          ],
                                        ),
                                        someErrorMessage == null
                                            ? const Text('')
                                            : Text('$someErrorMessage'),
                                      ],
                                    );
                                  },
                                ),
                              ],
                            )))))));
  }
}
