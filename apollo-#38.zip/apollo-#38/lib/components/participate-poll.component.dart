import 'package:awesome_poll_app/utils/commons.dart';
import 'package:grouped_list/grouped_list.dart';

class ParticipatePollComponent extends StatefulWidget {
  const ParticipatePollComponent({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return _ParticipatePollComponent();
  }
}

class _ParticipatePollComponent extends State<ParticipatePollComponent> {
  final ScrollController _scrollController = ScrollController();

  String status =
      ''; // status for whether poll is "active", "expired", or "upcoming"

  Color _statusColor(int startTime, int endTime) {
    if (endTime.compareTo(DateTime.now().millisecondsSinceEpoch) == -1) {
      return const Color(0xffFFA69E);
    } else if (endTime.compareTo(DateTime.now().millisecondsSinceEpoch) == 1 &&
        startTime.compareTo(DateTime.now().millisecondsSinceEpoch) == -1) {
      return const Color(0xff2A9D8F);
    } else if (startTime.compareTo(DateTime.now().millisecondsSinceEpoch) ==
        1) {
      return const Color(0xff979797);
    } else {
      return const Color(0xffffffff);
    }
  }

  Color _statusColorByString(String status) {
    if (status == 'expired') {
      return const Color(0xffFFA69E);
    } else if (status == 'active') {
      return const Color(0xff2A9D8F);
    } else if (status == 'upcoming') {
      return const Color(0xff979797);
    } else {
      return const Color(0xff000000);
    }
  }

  String _status(int startTime, int endTime) {
    if (endTime.compareTo(DateTime.now().millisecondsSinceEpoch) == -1) {
      status = 'expired';
      return status;
    } else if (endTime.compareTo(DateTime.now().millisecondsSinceEpoch) == 1 &&
        startTime.compareTo(DateTime.now().millisecondsSinceEpoch) == -1) {
      status = 'active';
      return status;
    } else if (startTime.compareTo(DateTime.now().millisecondsSinceEpoch) ==
        1) {
      status = 'upcoming';
      return status;
    } else {
      return status;
    }
  }

  String _subtitle(PollOverview item) {
    Duration active = DateTime.fromMillisecondsSinceEpoch(item.endTime)
        .difference(DateTime.now());
    Duration upcoming = DateTime.fromMillisecondsSinceEpoch(item.startTime)
        .difference(DateTime.now());

    if (_status(item.startTime, item.endTime) == 'active') {
      if (active.inDays > 1) {
        return 'ends in ${active.inDays} days \npeople voted: ${item.participants}';
      } else if (active.inDays == 1) {
        return 'ends in ${active.inDays} day \npeople voted: ${item.participants}';
      } else if (active.inHours > 0) {
        return 'ends in ${active.inHours} hours \npeople voted: ${item.participants}';
      } else if (active.inHours == 1) {
        return 'ends in ${active.inHours} hour \npeople voted: ${item.participants}';
      } else if (active.inMinutes > 1) {
        return 'ends in ${active.inMinutes} minutes \npeople voted: ${item.participants}';
      } else if (active.inMinutes == 1) {
        return 'ends in ${active.inMinutes} minute \npeople voted: ${item.participants}';
      } else if (active.inSeconds > 1) {
        return 'ends in ${active.inSeconds} seconds \npeople voted: ${item.participants}';
      } else if (active.inSeconds == 1) {
        return 'ends in ${active.inSeconds} second \npeople voted: ${item.participants}';
      }
    } else if (_status(item.startTime, item.endTime) == 'upcoming') {
      if (upcoming.inDays > 1) {
        return 'starts in ${upcoming.inDays} days';
      } else if (upcoming.inDays == 1) {
        return 'starts in ${upcoming.inDays} day';
      } else if (upcoming.inHours > 1) {
        return 'starts in ${upcoming.inHours} hours';
      } else if (upcoming.inHours == 1) {
        return 'starts in ${upcoming.inHours} hour';
      } else if (upcoming.inMinutes > 1) {
        return 'starts in ${upcoming.inMinutes} minutes';
      } else if (upcoming.inMinutes == 1) {
        return 'starts in ${upcoming.inMinutes} minute';
      } else if (upcoming.inSeconds > 1) {
        return 'starts in ${upcoming.inSeconds} seconds';
      } else if (upcoming.inSeconds == 1) {
        return 'starts in ${upcoming.inSeconds} second';
      }
    }
    return '';
  }

  @override
  Widget build(BuildContext context) {
    // Trigger an initial load of the nearby polls list
    getIt.get<API>().fetchListPollsNearby();
    return Scaffold(
      body: RefreshIndicator(
        onRefresh: () => getIt.get<API>().fetchListPollsNearby(),
        child: ValueListenableBuilder(
          valueListenable: getIt.get<API>().nearbyPolls,
          builder: (BuildContext context, List<PollOverview>? nearbyPolls,
              Widget? child) {
            if (nearbyPolls != null) {
              final items = <PollOverview>[];
              context.debug("items length is " + items.length.toString());

              if (nearbyPolls.isNotEmpty) {
                //add data from db
                for (PollOverview item in nearbyPolls) {
                  if (_status(item.startTime, item.endTime) != 'expired') {
                    items.add(item);
                  } //only add polls that aren't expired
                }
                //items.addAll(polls);
              } else {
                return Center(
                  child: Text(
                    'seems like there aren\'t any polls near you',
                    style: Theme.of(context).textTheme.headline6,
                  ),
                );
              }

              return polls_list(items, context);
            } else {
              return Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: const [
                    Center(child: CircularProgressIndicator()),
                    SizedBox(height: 10),
                    Center(child: Text("GPS must me enabled"))
                  ]);
            }
          }),
      )
    );
  }

  GroupedListView<PollOverview, String> polls_list(
      List<PollOverview> items, BuildContext context) {
    return GroupedListView<PollOverview, String>(
        elements: items,
        scrollDirection: Axis.vertical,
        controller: _scrollController,
        itemComparator: (item1, item2) {
          if (_status(item1.startTime, item1.endTime) == 'upcoming') {
            return item1.startTime.compareTo(item2.startTime);
          } else {
            return item2.endTime.compareTo(item1.endTime);
          }
        },
        groupBy: (item) => _status(item.startTime, item.endTime),
        groupSeparatorBuilder: (value) => Container(
              child: SizedBox(
                height: 30,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    color: _statusColorByString(value),
                  ),
                ),
              ),
            ),
        physics: const AlwaysScrollableScrollPhysics(),
        indexedItemBuilder: (_context, item, index) {
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: InkWell(
              onTap: () => {
                context.debug('tapped index $index , poll id: ${items[index].id}'),
                context.router
                    .push(PollParticipateRoute(pollId: items[index].id, overview: items[index])),
              },
              splashColor: Theme.of(context).colorScheme.secondary,
              highlightColor: Theme.of(context).colorScheme.primary,
              child: ListBody(children: [
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    ListTile(
                      contentPadding: const EdgeInsets.only(left: 20),
                      leading: SizedBox(
                        width: 20,
                        height: 20,
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            color: _statusColor(item.startTime, item.endTime),
                            shape: BoxShape.circle,
                          ),
                        ),
                      ), //const Icon(Icons.radar_rounded),
                      title: Text(item.title),
                      subtitle: Text(_subtitle(item)),
                      tileColor: Theme.of(context).colorScheme.background,
                    ),
                  ],
                )
              ]),
            ),
          );
        });
  }
}
