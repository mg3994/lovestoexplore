import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';

/// Wrapper class for holding the ThemeData and some other information, that cannot be added to [ThemeData]
class CustomTheme implements Equatable {
  final String name;
  final Map<String, Color> colors;
  /// a list of specific themes for particular widgets or parts of the app. 
  /// They can then be used with help of the [Theme] Widget
  final Map<String, ThemeData> _widgetThemes;
  final ThemeData themeData;

  CustomTheme(this.name, this.colors, this._widgetThemes, this.themeData);

  ThemeData getWidgetTheme(String name) {
    // return specific themeData if existent, else return general themeData. ?? is the Null Coalescing operator
    return _widgetThemes[name] ?? themeData;
  }

  @override
  List<Object?> get props => [name];

  @override
  bool? get stringify => true;

}