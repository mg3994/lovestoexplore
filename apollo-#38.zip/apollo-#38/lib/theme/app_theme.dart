import 'package:awesome_poll_app/utils/commons.dart';

class AppThemeCubit extends Cubit<CustomTheme> with HydratedMixin {
  AppThemeCubit() : super(Themes.lightTheme);

  set theme(CustomTheme theme) => emit(theme);

  CustomTheme get theme {
    return state;
  }

  @override
  CustomTheme? fromJson(Map<String, dynamic> json) {
    var theme = json['theme'];
    if(theme != null && theme is String) {
      return Themes.listThemes().firstWhere((e) => e.name == theme);
    }
    return null;
  }

  @override
  Map<String, dynamic>? toJson(CustomTheme state) => {
    'theme': state.name,
  };

}