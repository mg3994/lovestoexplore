import 'package:injectable/injectable.dart';

const local = Environment('local');
const firebase = Environment('firebase');