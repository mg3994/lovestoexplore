from firebase_connection import db
import json

path_polls = 'polls'

def listPollsNearby(longitude, latitude):


    def isInReach(poll, longitude, latitude):
        return pow((longitude - poll['longitude']), 2) + pow((latitude - poll['latitude']), 2) < poll['radius']
        
    poll_list_ordered_dict = db.child(path_polls).get().val()
    # convert to dict
    poll_list_dict = json.loads(json.dumps(poll_list_ordered_dict))
    poll_list_filtered = {k: v for k,v in poll_list_dict.items() if isInReach(v, longitude, latitude)}

    return poll_list_filtered