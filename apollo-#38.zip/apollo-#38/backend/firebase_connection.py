import firebase_admin
import pyrebase
import json
from firebase_admin import credentials, auth

# Firebase Admin Connection
# TODO: The file fbadmin.json should not be made public!!! See https://firebase.google.com/docs/admin/setup#initialize-sdk
cred = credentials.Certificate('fbadmin.json')
firebase = firebase_admin.initialize_app(cred)
pb = pyrebase.initialize_app(json.load(open('fbconfig.json')))


db = pb.database()