#!/usr/bin/env bash
docker build -t ipt:latest .