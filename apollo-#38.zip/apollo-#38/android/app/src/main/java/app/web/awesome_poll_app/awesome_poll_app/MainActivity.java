package app.web.awesome_poll_app.awesome_poll_app;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
